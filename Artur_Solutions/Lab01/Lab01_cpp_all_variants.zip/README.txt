Lab Work 01 — C++ solutions for variants 1–10

Each file contains both required calculations:
1) int variables
2) float variables

Compile example:
  g++ -std=c++17 -Wall -Wextra -pedantic variant01.cpp -o variant01

The programs intentionally do not use if/switch/loops, in accordance with Lab 01 requirements.
